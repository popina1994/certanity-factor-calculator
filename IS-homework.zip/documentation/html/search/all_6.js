var searchData=
[
  ['observe',['observe',['../classetf_1_1cfactor_1_1zd130033d_1_1_klase_1_1_opazanje.html#af3ec5b2974e80c0865230ed961214a78',1,'etf::cfactor::zd130033d::Klase::Opazanje']]],
  ['opazanje',['Opazanje',['../classetf_1_1cfactor_1_1zd130033d_1_1_klase_1_1_opazanje.html',1,'etf::cfactor::zd130033d::Klase']]]
];
