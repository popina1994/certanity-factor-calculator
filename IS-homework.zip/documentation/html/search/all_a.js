var searchData=
[
  ['update',['Update',['../classetf_1_1cfactor_1_1zd130033d_1_1_klase_1_1_zakljucak.html#a2d3a0eaae989936f8931bbd667930e14',1,'etf::cfactor::zd130033d::Klase::Zakljucak']]]
];
