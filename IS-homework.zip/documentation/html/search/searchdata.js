var indexSectionsWithContent =
{
  0: "acdefioprsuz",
  1: "aefopz",
  2: "e",
  3: "cdeiu",
  4: "cors"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "functions",
  4: "variables"
};

var indexSectionLabels =
{
  0: "Све",
  1: "Класе",
  2: "Простори имена",
  3: "Функције",
  4: "Променљиве"
};

