var searchData=
[
  ['conclusion',['conclusion',['../classetf_1_1cfactor_1_1zd130033d_1_1_klase_1_1_zakljucak.html#a311bd6a583908ee87ffd93e218615a2f',1,'etf::cfactor::zd130033d::Klase::Zakljucak']]],
  ['curstep',['curStep',['../classetf_1_1cfactor_1_1zd130033d_1_1_klase_1_1_algoritam.html#aeadbcfb574228f6266a777b296d62946',1,'etf::cfactor::zd130033d::Klase::Algoritam']]]
];
